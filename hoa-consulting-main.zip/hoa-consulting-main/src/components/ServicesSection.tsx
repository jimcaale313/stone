import { 
  Building2, 
  TrendingUp, 
  Users, 
  FileText, 
  Globe, 
  Lightbulb,
  ArrowRight 
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const ServicesSection = () => {
  const services = [
    {
      icon: Building2,
      title: "Organizational Development",
      description: "Strategic planning, leadership development, and institutional capacity building tailored to regional contexts.",
      features: [
        "Strategic planning & implementation",
        "Leadership development programs",
        "Organizational restructuring",
        "Change management"
      ]
    },
    {
      icon: TrendingUp,
      title: "Business Strategy",
      description: "Market analysis, business model innovation, and growth strategies for sustainable competitive advantage.",
      features: [
        "Market entry strategies",
        "Business model innovation",
        "Competitive analysis",
        "Growth planning"
      ]
    },
    {
      icon: Users,
      title: "Stakeholder Engagement",
      description: "Community consultation, partnership facilitation, and stakeholder mapping for inclusive development.",
      features: [
        "Community engagement",
        "Partnership development",
        "Stakeholder analysis",
        "Conflict resolution"
      ]
    },
    {
      icon: FileText,
      title: "Policy & Research",
      description: "Evidence-based policy development, research studies, and impact assessments for informed decision-making.",
      features: [
        "Policy analysis & development",
        "Research & evaluation",
        "Impact assessments",
        "Data collection & analysis"
      ]
    },
    {
      icon: Globe,
      title: "International Development",
      description: "Program design, implementation support, and monitoring & evaluation for development initiatives.",
      features: [
        "Program design & implementation",
        "Monitoring & evaluation",
        "Grant writing & fundraising",
        "Donor relations"
      ]
    },
    {
      icon: Lightbulb,
      title: "Innovation & Technology",
      description: "Digital transformation, innovation strategies, and technology adoption for modern organizational growth.",
      features: [
        "Digital transformation",
        "Innovation frameworks",
        "Technology adoption",
        "Process optimization"
      ]
    }
  ];

  return (
    <section id="services" className="py-20 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            What We Do
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive consulting services designed to address the unique challenges 
            and opportunities in the Horn of Africa region.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <Card key={index} className="group hover:shadow-medium transition-all duration-300 border-border bg-card">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-secondary/10 transition-colors duration-300">
                    <IconComponent className="h-6 w-6 text-primary group-hover:text-secondary transition-colors duration-300" />
                  </div>
                  <CardTitle className="text-xl font-semibold text-foreground">
                    {service.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    {service.description}
                  </p>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-sm text-muted-foreground">
                        <ArrowRight className="h-3 w-3 text-secondary mr-2 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* CTA Section */}
        <div className="text-center bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-foreground mb-4">
            Ready to Transform Your Organization?
          </h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Let's discuss how our expertise can help you achieve your strategic objectives 
            and create lasting impact in your community.
          </p>
          <Button size="lg" className="bg-secondary hover:bg-secondary-light">
            Get Started Today
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;