import { ExternalLink, Calendar, MapPin, Users } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const ProjectsSection = () => {
  const projects = [
    {
      title: "Regional Healthcare Network Optimization",
      client: "East African Health Consortium",
      location: "Ethiopia, Kenya, Somalia",
      duration: "18 months",
      challenge: "Fragmented healthcare delivery systems across multiple countries with limited coordination and resource sharing.",
      outcome: "Established unified healthcare network serving 2.3M people, reduced costs by 35%, improved patient outcomes by 40%.",
      tags: ["Healthcare", "Multi-country", "System Integration"],
      featured: true
    },
    {
      title: "Agricultural Value Chain Development",
      client: "Horn of Africa Development Bank",
      location: "Sudan, South Sudan",
      duration: "24 months",
      challenge: "Smallholder farmers lacking access to markets, financing, and modern agricultural techniques.",
      outcome: "Connected 15,000 farmers to markets, increased average income by 60%, established 12 cooperative societies.",
      tags: ["Agriculture", "Economic Development", "Rural Communities"]
    },
    {
      title: "Youth Employment Initiative",
      client: "Regional Youth Foundation",
      location: "Djibouti, Eritrea",
      duration: "12 months",
      challenge: "High youth unemployment rates and limited vocational training opportunities in urban areas.",
      outcome: "Trained 5,000 youth in marketable skills, achieved 78% job placement rate, launched 200 micro-enterprises.",
      tags: ["Youth Development", "Skills Training", "Employment"]
    },
    {
      title: "Climate Resilience Planning",
      client: "Inter-Governmental Authority on Development",
      location: "Regional (8 countries)",
      duration: "15 months",
      challenge: "Increasing climate variability threatening food security and economic stability across the region.",
      outcome: "Developed climate adaptation strategies for 8 countries, secured $150M climate financing, improved early warning systems.",
      tags: ["Climate Change", "Policy Development", "Regional Cooperation"],
      featured: true
    },
    {
      title: "Digital Financial Inclusion",
      client: "Regional Microfinance Network",
      location: "Uganda, Tanzania",
      duration: "20 months",
      challenge: "Limited access to financial services in rural areas, low digital literacy among target populations.",
      outcome: "Launched mobile banking platform serving 500,000 users, increased financial inclusion by 45%, reduced transaction costs by 60%.",
      tags: ["Fintech", "Digital Transformation", "Financial Inclusion"]
    },
    {
      title: "Education System Strengthening",
      client: "Ministry of Education Partnership",
      location: "Rwanda, Burundi",
      duration: "30 months",
      challenge: "Outdated curriculum, insufficient teacher training, and inadequate educational infrastructure.",
      outcome: "Modernized curriculum for 1,200 schools, trained 8,000 teachers, improved literacy rates by 25%.",
      tags: ["Education", "Capacity Building", "Teacher Training"]
    }
  ];

  const featuredProjects = projects.filter(project => project.featured);
  const regularProjects = projects.filter(project => !project.featured);

  return (
    <section id="projects" className="py-20 bg-gradient-to-b from-muted/30 to-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Our Projects
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Transformative initiatives across the Horn of Africa that demonstrate our commitment 
            to creating sustainable impact and driving meaningful change.
          </p>
        </div>

        {/* Featured Projects */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-foreground mb-8 text-center">Featured Projects</h3>
          <div className="grid md:grid-cols-2 gap-8">
            {featuredProjects.map((project, index) => (
              <Card key={index} className="bg-gradient-to-br from-primary/5 to-secondary/5 border-primary/20 hover:shadow-medium transition-all duration-300">
                <CardHeader>
                  <div className="flex items-start justify-between mb-4">
                    <Badge variant="secondary" className="bg-secondary text-secondary-foreground">
                      Featured
                    </Badge>
                    <div className="flex gap-2 text-muted-foreground text-sm">
                      <MapPin className="h-4 w-4" />
                      <span>{project.location}</span>
                    </div>
                  </div>
                  <CardTitle className="text-xl font-bold text-foreground mb-2">
                    {project.title}
                  </CardTitle>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      <span>{project.client}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      <span>{project.duration}</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Challenge</h4>
                      <p className="text-muted-foreground text-sm leading-relaxed">
                        {project.challenge}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Outcome</h4>
                      <p className="text-muted-foreground text-sm leading-relaxed">
                        {project.outcome}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {project.tags.map((tag, tagIndex) => (
                        <Badge key={tagIndex} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Regular Projects Grid */}
        <div className="mb-12">
          <h3 className="text-2xl font-bold text-foreground mb-8 text-center">Recent Projects</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {regularProjects.map((project, index) => (
              <Card key={index} className="hover:shadow-medium transition-all duration-300 bg-card border-border">
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-1 text-muted-foreground text-xs">
                      <MapPin className="h-3 w-3" />
                      <span>{project.location}</span>
                    </div>
                    <div className="flex items-center gap-1 text-muted-foreground text-xs">
                      <Calendar className="h-3 w-3" />
                      <span>{project.duration}</span>
                    </div>
                  </div>
                  <CardTitle className="text-lg font-semibold text-foreground">
                    {project.title}
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">{project.client}</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-medium text-foreground text-sm mb-1">Challenge</h4>
                      <p className="text-muted-foreground text-xs leading-relaxed">
                        {project.challenge}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-medium text-foreground text-sm mb-1">Outcome</h4>
                      <p className="text-muted-foreground text-xs leading-relaxed">
                        {project.outcome}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {project.tags.map((tag, tagIndex) => (
                        <Badge key={tagIndex} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-card rounded-2xl p-8 border border-border">
          <h3 className="text-2xl font-bold text-foreground mb-4">
            Interested in Our Project Portfolio?
          </h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Download our comprehensive case study archive to explore detailed insights 
            from our most impactful projects across the Horn of Africa.
          </p>
          <Button variant="outline" size="lg">
            <ExternalLink className="mr-2 h-5 w-5" />
            Download Case Studies
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;