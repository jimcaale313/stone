import { ArrowRight, MapPin, Users, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroBackground from "@/assets/hero-background.jpg";

const HeroSection = () => {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Image */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(${heroBackground})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      >
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-primary/70"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-4xl mx-auto">
          {/* Main Tagline */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-primary-foreground mb-6 leading-tight">
            Delivering Results.
            <br />
            <span className="text-secondary">Driving Change.</span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-primary-foreground/90 mb-8 max-w-3xl mx-auto leading-relaxed">
            Strategic consulting expertise focused on the Horn of Africa region.
            We partner with organizations to create sustainable impact and drive
            meaningful transformation.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button
              size="lg"
              className="bg-secondary hover:bg-secondary-light text-secondary-foreground font-semibold px-8 py-3 text-lg"
            >
              <a href="https://calendly.com/abdirisakhd1/30min" target="_blank">
                Work With Us
              </a>
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-primary-foreground hover:bg-primary-foreground text-primary font-semibold px-8 py-3 text-lg"
            >
              Learn More
            </Button>
          </div>

          {/* Key Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
            <div className="flex flex-col items-center text-primary-foreground">
              <MapPin className="h-8 w-8 text-secondary mb-2" />
              <h3 className="text-2xl font-bold">Horn of Africa</h3>
              <p className="text-primary-foreground/80">Regional Focus</p>
            </div>
            <div className="flex flex-col items-center text-primary-foreground">
              <Users className="h-8 w-8 text-secondary mb-2" />
              <h3 className="text-2xl font-bold">50+ Projects</h3>
              <p className="text-primary-foreground/80">
                Successfully Delivered
              </p>
            </div>
            <div className="flex flex-col items-center text-primary-foreground">
              <TrendingUp className="h-8 w-8 text-secondary mb-2" />
              <h3 className="text-2xl font-bold">Proven Impact</h3>
              <p className="text-primary-foreground/80">Measurable Results</p>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
        <div className="w-6 h-10 border-2 border-primary-foreground rounded-full flex justify-center">
          <div className="w-1 h-3 bg-primary-foreground rounded-full mt-2 animate-bounce"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
