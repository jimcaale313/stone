import { Target, Eye, Heart, Award } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const AboutSection = () => {
  const values = [
    {
      icon: Target,
      title: "Strategic Excellence",
      description: "We deliver data-driven solutions with proven methodologies and deep regional expertise."
    },
    {
      icon: Heart,
      title: "Authentic Partnership",
      description: "We build lasting relationships based on trust, transparency, and shared commitment to success."
    },
    {
      icon: Award,
      title: "Impact Focus",
      description: "Every engagement is designed to create measurable, sustainable change for our clients and communities."
    },
    {
      icon: Eye,
      title: "Cultural Intelligence",
      description: "Our deep understanding of Horn of Africa contexts ensures culturally appropriate and effective solutions."
    }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Who We Are
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A strategic consulting firm specializing in the Horn of Africa region, 
            committed to delivering exceptional results and driving meaningful change.
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid md:grid-cols-2 gap-12 mb-20">
          <div className="text-center md:text-left">
            <h3 className="text-2xl font-bold text-primary mb-4 flex items-center justify-center md:justify-start">
              <Target className="h-6 w-6 text-secondary mr-2" />
              Our Mission
            </h3>
            <p className="text-lg text-muted-foreground leading-relaxed">
              To empower organizations across the Horn of Africa with strategic insights, 
              innovative solutions, and sustainable practices that drive lasting positive change 
              in communities and economies.
            </p>
          </div>
          <div className="text-center md:text-left">
            <h3 className="text-2xl font-bold text-primary mb-4 flex items-center justify-center md:justify-start">
              <Eye className="h-6 w-6 text-secondary mr-2" />
              Our Vision
            </h3>
            <p className="text-lg text-muted-foreground leading-relaxed">
              To be the leading strategic consulting partner in the Horn of Africa, 
              recognized for our expertise, integrity, and transformative impact on 
              regional development and organizational success.
            </p>
          </div>
        </div>

        {/* Values */}
        <div>
          <h3 className="text-2xl font-bold text-center text-foreground mb-12">
            Our Values
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const IconComponent = value.icon;
              return (
                <Card key={index} className="text-center border-0 shadow-soft hover:shadow-medium transition-all duration-300 bg-card">
                  <CardContent className="p-6">
                    <div className="w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="h-8 w-8 text-secondary" />
                    </div>
                    <h4 className="text-xl font-semibold text-foreground mb-3">
                      {value.title}
                    </h4>
                    <p className="text-muted-foreground leading-relaxed">
                      {value.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;